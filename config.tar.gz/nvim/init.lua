-- ~/nvim/init.lua

-- imports
require("kauntey101.settings") -- editor settings
require("kauntey101.lazy") -- lazy.nvim plugin
