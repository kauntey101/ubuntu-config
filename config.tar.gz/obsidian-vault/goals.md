1. Have minimum sleep possible.
2. Fields to excel : problem solving and machine learning.
3. Languages to excel : python, c++ and assembly.
4. Cover all Data structures and algorithms with implementations.
5. Create a side project and work upon it.
6. Simplify your knowledge 
7. Learn and use Elon and Jobs philosophy of work and design in day to day life.