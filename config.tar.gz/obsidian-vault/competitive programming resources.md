1. gfg
2. codechef
3. codeforces discussions and blogs 
4. Competitive programming with shayan - https://www.youtube.com/@CPwithShayan
5. USACO guide
6. TLE Eliminators