
1. Use Headphones for silence 
2. fix your mind than fixing up the situation
3. Do everything seriously (study)
4. Be free and explore - be an adventurer
5. Be focused and don't accept all opportunities. 
6. Don't overthink.