1. Wake Up at 2 - (Max 4:30 hours of sleep)
2. Wash Face, Brush Teeth, Fill water bottle
3. Solve DSA Problems till 7 or 7:30 
4. Go to exercise with yoga mat and run and meditate & stretch 
5. Take Bath and get ready 
6. Revision of DSA Topics and Subjects or solve DSA problems if you didn't solve them in the morning.
7. Lunch (3 rotis max) 
8. College 
9. Self Study DSA - 45 mins sets and 5 mins breaks
10. Get Back to Room and Play football or watch series (No youtube or music )depending upon the weather.
11. Get fresh 
12. Dinner 
13. Get fresh again 
14. Read the syllabus book and do some coding.
15. Night skin care & sleep with headphones on.

