1. Red Black Trees
2. Java programming Basics
3. Options trading